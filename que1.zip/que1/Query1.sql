1.Create a database name - “Employee”.
CREATE DATABASE Employee;
