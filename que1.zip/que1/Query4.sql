4)Find the salaries of all the employees from the “Employee Details” table.

SQL> select salary from employee_details;
