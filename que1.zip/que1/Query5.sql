5) Find the unique designations of the employees from the table:

SQL> select distinct job_name from employee_details;