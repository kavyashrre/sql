1.Create a database name - "Football":


create user Football identified by system;
