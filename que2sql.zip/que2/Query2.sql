2.Create a table name - "Football Venue":
USE Football;

SQL> create table football_venue
    (
    venue_id number(4),
   venue_name varchar2(20),
    city_id number(4),
    capacity number(7)
    );
 Table created.