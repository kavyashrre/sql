3.Insert 10 details in the "Football Venue" table:

SQL> insert into football_venue values(1,'webleystatidum',1,90000);
1 row created.
SQL> insert into football_venue values(2,'oldtrafoord',2,75000);
1 row created.
SQL> insert into football_venue values (3, 'Emirates Stadium', 1, 60000);
1 row created.
SQL> insert into football_venue values(4, 'Anfield', 3, 54074);
1 row created.
SQL> insert into football_venue values(5, 'Etihad Stadium', 2, 55097);
1 row created.
SQL> insert into football_venue values  (6, 'Stamford Bridge', 1, 40853);
1 row created.
SQL> insert into football_venue values  (7, 'Tottenham Stadium', 1, 62062);
1 row created.
SQL> insert into football_venue values  (8, 'Villa Park', 4, 42785);
1 row created.
SQL> insert into football_venue values  (9, 'Elland Road', 5, 37916);
1 row created.
SQL> insert into football_venue values  (10, 'King Power Stadium', 6, 32262);
1 row created.