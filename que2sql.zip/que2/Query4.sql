4.Count the number of venues of the football world cup:
SQL> select count(*) from Football_venue;