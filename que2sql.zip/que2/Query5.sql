5.List all the venue names and capacities in the format of "Location" and "Volume":

SQL> alter table Football_venue
   2  rename column venue_name to Location;

SQL> alter table Football_venue
  2  rename column capacity to volume;

SQL>select * from Football_venue;

SQL> select Location,volume from Football_venue;
